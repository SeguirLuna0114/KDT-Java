--MySQL
show tables;
select * from boards;

-- boards 테이블이 자동으로 생성되어 있음


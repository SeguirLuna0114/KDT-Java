show tables;
select * from members;

-- members 테이블이 자동으로 생성되어 있음

drop table members;

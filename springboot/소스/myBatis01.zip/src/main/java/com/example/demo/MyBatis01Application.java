package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyBatis01Application {

	public static void main(String[] args) {
		SpringApplication.run(MyBatis01Application.class, args);
	}

}

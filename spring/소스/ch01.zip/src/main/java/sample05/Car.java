package sample05;

public class Car implements Vehicle {
	public void ride(String name) {
		System.out.println(name + "(이)가 자동차를 탄다");
	}
}
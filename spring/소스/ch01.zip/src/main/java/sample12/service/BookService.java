package sample12.service;

import sample12.model.Book;

public interface BookService {
	Book getBook();
}
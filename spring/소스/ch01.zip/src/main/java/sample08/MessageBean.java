package sample08;

public interface MessageBean {
	void syaHello();
}
package sample15;

public interface BookService {
	Book getBook();
}
package sample07;

public interface MessageBean {
	void sayHello();
}
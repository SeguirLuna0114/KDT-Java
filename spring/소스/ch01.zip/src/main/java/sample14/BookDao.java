package sample14;

public interface BookDao {
	Book getBook(String title);
}
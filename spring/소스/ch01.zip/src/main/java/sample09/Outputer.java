package sample09;

public interface Outputer {
	void output(String msg);
}
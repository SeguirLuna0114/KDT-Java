package sample01;

public class Ex01 {
	public static void main(String[] args) {
		// MessageBeanEn mb = new MessageBeanEn();
		MessageBeanKr mb = new MessageBeanKr();
		mb.sayHello("Spring");
	}
}
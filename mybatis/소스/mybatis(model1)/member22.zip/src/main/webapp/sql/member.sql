-- 회원관리
select * from tab;
select * from member22;

create table member22 (
	id varchar2(10) primary key,
	password varchar2(10)
);


